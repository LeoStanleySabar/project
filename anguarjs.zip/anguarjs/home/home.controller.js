﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['$window', '$http', '$scope', '$location'];
    function HomeController($window, $http, $scope, $location) {
        var vm = this;

        initController();

        function initController() {

            $http({
                url: 'https://fakestoreapi.com/products/categories',
                method: "GET"
            }).then(function (response) {
                $scope.Categories = response.data;
                //console.log(Categories);
            },function(error){
                console.log(error);
            });
        };

        $scope.categoryselection = function () {
            if ($scope.category != "" && $scope.category != undefined){
                console.log($scope.category);
                $location.path('/products/' + $scope.category);
            }else
            $scope.msg = 'Please Select Dropdown Value';
        };

        function getproducts () {
            $http({
                url: 'https://fakestoreapi.com/products/category/'+$scope.category,
                method: "GET"
            }).then(function (response) {
                $scope.products = response.data;
                //console.log(response.data);
            },function(error){
                console.log(error);
            });
        };

        function getproduct () {
            $http({
                url: 'https://fakestoreapi.com/products/category/'+$scope.category,
                method: "GET"
            }).then(function (response) {
                $scope.products = response.data;
                //console.log(response.data);
            },function(error){
                console.log(error);
            });
        };


        $scope.logout = function(){
            $window.sessionStorage.setItem('userData', '');
            $http.defaults.headers.common['Authorization'] = 'Basic';
        }
    }

})();