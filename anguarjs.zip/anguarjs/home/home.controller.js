﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['$window', '$http', '$scope', '$location'];
    function HomeController($window, $http, $scope, $location) {
        var vm = this;
        var email = JSON.parse($window.sessionStorage.getItem("userData")).email;
        initController();

        function initController() {

            $http({
                url: 'http://localhost:9090/shoppingcart/user/'+email,
                method: "GET",
                headers: {
                    'Accept': 'application/json'                        
                } 
            }).then(function (response) {
                var user=response.data;
                
                $window.sessionStorage.setItem('userId', user.userId);
                $scope.userName=user.name;

            },function(error){
                console.log(error);
            });

            $http({
                url: 'http://localhost:9090/products/categories',
                method: "GET",
                headers: {
                    'Accept': 'application/json'                        
                }
            }).then(function (response) {
                $scope.Categories = response.data;

            },function(error){
                console.log(error);
            });
        };

        $scope.categoryselection = function () {
            if ($scope.category != "" && $scope.category != undefined){
                console.log($scope.category);
                $location.path('/products/' + $scope.category);
            }else
            $scope.msg = 'Please Select Dropdown Value';
        };

        function getproducts () {
            $http({
                url: 'http://localhost:9090/products/category/'+$scope.category,
                method: "GET",
                headers: {
                    'Accept': 'application/json'                        
                }
            }).then(function (response) {
                $scope.products = response.data;

            },function(error){
                console.log(error);
            });
        };

        $scope.logout = function(){
            $window.sessionStorage.setItem('userData', '');
            $http.defaults.headers.common['Authorization'] = 'Basic';
        }
    }

})();