﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ProductsController', ProductsController);

    ProductsController.$inject = ['$window', '$http', '$scope' , '$routeParams', '$location'];
    function ProductsController($window, $http, $scope, $routeParams, $location) {
        var vm = this;
        var ratingTotal = 5;
        var catgry= $routeParams.category;
        initController();

        function initController() {
            console.log(catgry);
            $http({
                url: 'http://localhost:9090/products/category/'+catgry,
                method: "GET",
                headers: {
                    'Accept': 'application/json'                        
                }
            }).then(function (response) {
                $scope.products = response.data;
            },function(error){
                console.log(error);
            });
        };

        

        $scope.getRepeater = function() {
            return new Array(ratingTotal);
        };

        $scope.productselection = function (product) {
            if (product.id != "" && product.id != undefined){
                console.log(product.id);
                $location.path('/product/' + product.id);
            }else
            $scope.msg = 'Please Select Product';
        };

        function getproduct (product) {
            $http({
                url: 'http://localhost:9090/products/'+product.id,
                method: "GET",
                headers: {
                    'Accept': 'application/json'                        
                }
            }).then(function (response) {
                $scope.product = response.data;
                //console.log(response.data);
            },function(error){
                console.log(error);
            });
        };

        $scope.logout = function(){
            $window.sessionStorage.setItem('userData', '');
            $http.defaults.headers.common['Authorization'] = 'Basic';
        }
    }

})();