(function () {
    'use strict';

    angular
        .module('app')
        .controller('CartController', CartController);

    CartController.$inject = ['$window', '$http', '$scope', '$location'];
    function CartController($window, $http, $scope, $location) {
        var vm = this;
        var userId=$window.sessionStorage.getItem("userId")
        initController();

        function initController() {

            $http({
                url: 'http://localhost:9090/shoppingCart',
                method: "GET",
                headers: {
                    'Accept': 'application/json'                        
                } 
            }).then(function (response) {
                $scope.shoppingCart=response.data;
                console.log($scope.shoppingCart);

            },function(error){
                console.log(error);
            });
        };      

            $scope.updateCart = function (shoppingCart, stock) {
                $scope.shoppingCart = {};
                if ($scope.shoppingCart.stock = stock == null) {
                    $scope.shoppingCart.stock = shoppingCart.stock;
                } else {
                    $scope.shoppingCart.stock = stock;
                }
                $http.put('http://localhost:9090/shoppingCart/' + shoppingCart.shoppingId, $scope.shoppingCart);
                $window.location.reload();
                $location.path('/cart');  
            };
    
            $scope.deleteProduct = function (shoppingCart) {
                $scope.shoppingCart = {};
                $http.delete('http://localhost:9090/shoppingCart/' + shoppingCart.shoppingId);
                $window.location.reload();
                $location.path('/cart');  
            };
    
    
            $scope.clearCart = function (shoppingCart) {
                $http.delete('http://localhost:9090/shoppingCart/');
                $location.path('/home');  
            };
    
    
            $scope.purchaseProducts = function (shoppingCart) {
                console.log(shoppingCart);              
                $scope.purchaseCart=shoppingCart;
                buy(refresh)
                
            };

            function buy(callback) {
                setTimeout(function() {
                    var i = 0;
                    for (i = 0; i < $scope.purchaseCart.length; i++) {
                        $http.post('http://localhost:9090/shoppingCart/purchase/' + $scope.purchaseCart[i].shoppingId);
                    }
                  callback();
                }, 500);
              }
              
              function refresh() {
                $location.path('/history');  
              }
              
             

        $scope.logout = function(){
            $window.sessionStorage.setItem('userData', '');
            $http.defaults.headers.common['Authorization'] = 'Basic';
        }
    }
    

})();