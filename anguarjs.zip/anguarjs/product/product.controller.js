﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ProductController', ProductController);

    ProductController.$inject = ['$window', '$http', '$scope', '$routeParams'];
    function ProductController($window, $http, $scope, $routeParams) {
        var vm = this;
        var ratingTotal = 5;
        var id= $routeParams.productId;
        var prods=[];
        initController();

        function initController() {
           
            $http({
                url: 'https://fakestoreapi.com/products/'+id,   
                method: "GET"
            }).then(function (response) {
                prods.push(response.data);
                $scope.products = prods;
                // console.log(response.data);
            },function(error){
                console.log(error);
            });
        };      

        $scope.getRepeater = function() {
            return new Array(ratingTotal);
        };

        $scope.getproducts = function (event) {
            $http({
                url: 'https://fakestoreapi.com/products/',
                method: "GET"
            }).then(function (response) {
                $scope.products = response.data;
            },function(error){
                console.log(error);
            });            
            
        };            

        $scope.addToCart = function (product, stock) {
            $scope.itemCounter += 1;
            $scope.shoppingCart = {};
            $scope.shoppingCart.productId = product.id;
            $scope.shoppingCart.status = "NOT_PURCHASED";

            $http.post('http://localhost:9090/shoppingcart/shoppingCart', $scope.shoppingCart);
        };

        $scope.logout = function(){
            $window.sessionStorage.setItem('userData', '');
            $http.defaults.headers.common['Authorization'] = 'Basic';
        }
    }

})();