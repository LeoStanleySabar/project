﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ProductController', ProductController);

    ProductController.$inject = ['$window', '$http', '$scope', '$routeParams'];
    function ProductController($window, $http, $scope, $routeParams) {
        var vm = this;
        var ratingTotal = 5;
        var id= $routeParams.productId;
        var prods=[];
        var userId=$window.sessionStorage.getItem("userId");
        console.log(userId);
        $scope.itemCounter = 0;
        $scope.total = 0;
        initController();
        

        function initController() {
           
            $http({
                url: 'http://localhost:9090/products/'+id,   
                method: "GET",
                headers: {
                    'Accept': 'application/json'                        
                }
            }).then(function (response) {
                prods.push(response.data);
                $scope.products = prods;
                // console.log(response.data);
            },function(error){
                console.log(error);
            });
        };      

        $scope.getRepeater = function() {
            return new Array(ratingTotal);
        };

        $scope.getproducts = function (event) {
            $http({
                url: 'http://localhost:9090/products/',
                method: "GET",
                headers: {
                    'Accept': 'application/json'                        
                }
            }).then(function (response) {
                $scope.products = response.data;
            },function(error){
                console.log(error);
            });            
            
        };            

        $scope.addToCart = function (product, stock) {
            $scope.itemCounter += 1;
            $scope.shoppingCart = {};
            $scope.shoppingCart.id = product.id;
            $scope.shoppingCart.userId = userId;
            $scope.shoppingCart.status = "NOT_PURCHASED";
            console.log($scope.itemCounter);
            if(angular.isUndefined(stock)){
                $scope.shoppingCart.stock = 1;
            }else {
                $scope.shoppingCart.stock = stock;
            }
            $scope.total += $scope.shoppingCart.stock*product.price;
            $http({
                method: 'POST',
                url: 'http://localhost:9090/shoppingCart',
                data: angular.toJson($scope.shoppingCart),
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8'
                }
            })
        };

        $scope.logout = function(){
            $window.sessionStorage.setItem('userData', '');
            $http.defaults.headers.common['Authorization'] = 'Basic';
        }
    }

})();