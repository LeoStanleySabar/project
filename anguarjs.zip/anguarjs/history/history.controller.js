
(function () {
    'use strict';

    angular
        .module('app')
        .controller('HistoryController', HistoryController);

    HistoryController.$inject = ['$window', '$http', '$scope', '$location'];
    function HistoryController($window, $http, $scope, $location) {
        var vm = this;
        initController();

        function initController() {

            $http({
                url: 'http://localhost:9090/history',
                method: "GET",
                headers: {
                    'Accept': 'application/json'                        
                } 
            }).then(function (response) {
                $scope.history1 =response.data;
                $scope.userName=user.name;

            },function(error){
                console.log(error);
            });
        }

        $scope.logout = function(){
            $window.sessionStorage.setItem('userData', '');
            $http.defaults.headers.common['Authorization'] = 'Basic';
        }
    }
    

})();